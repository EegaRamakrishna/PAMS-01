package com.revature.pams.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;

import com.revature.pams.DataBaseConnection.Dbconnection;
import com.revature.pams.model.LoginCredentials;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

//import com.revature.pams.DataBaseConnection.DataBaseConnection.Dbconnection;

/**
 * Servlet implementation class LoginSerlvet
 */
@WebServlet("/LoginSerlvet")
public class LoginSerlvet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	LoginCredentials loginCredentials=new LoginCredentials();
	 public LoginSerlvet() throws SQLException {
	    }
       
	Dbconnection dbconnection = null;
	Connection connection = Dbconnection.getConnection();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");

		loginCredentials.setUsername(request.getParameter("username"));
		
		loginCredentials.setPassword(request.getParameter("password"));
		HttpSession session=request.getSession(true);
		RequestDispatcher dispatcher;
		try {
			PreparedStatement PStm=connection.prepareStatement("select Receptionist_name,password from pams_own.receptionist where Receptionist_name=? and password=? ");
			PStm.setString(1, loginCredentials.getUsername());
			PStm.setString(2, loginCredentials.getPassword());
			System.out.println(PStm);
			
			ResultSet rs=PStm.executeQuery();
			if(rs.next()) {
                dispatcher=request.getRequestDispatcher("receptionistLogedin.jsp");
                dispatcher.forward(request, response);
//                System.out.println(rs.getString(1));
               
                if (Objects.isNull(session)) {
                	response.setIntHeader("Refresh", 1);
//					response.sendRedirect("login.jsp");
					System.out.println("this obj112");
					return;
				}
				session.setAttribute("username", rs.getString(1));
				System.out.println(session.getAttribute("username"));
//				System.out.println(rs.getString(1)+" hidbvkdjvksdnkjn" +rs.getString(2));

			}
            else{
                request.setAttribute("status", "failed");
                System.out.println("not availble");
                dispatcher=request.getRequestDispatcher("login.jsp");
//                            response.sendRedirect("bookappointment.html");
                dispatcher.include(request, response);
//                response.setIntHeader("Refresh", 1);
            }
		} catch (SQLException e)
		{
			e.printStackTrace();
			}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
