package com.revature.pams.model.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.revature.pams.DataBaseConnection.Dbconnection;
import com.revature.pams.model.BookingPatientAppointment;




public class Bookingappointmentimpl {
	BookingPatientAppointment bookap=new BookingPatientAppointment();
	Connection connection = Dbconnection.getConnection();

	public List<BookingPatientAppointment> bookappointment() {
		List<BookingPatientAppointment> list=new ArrayList<	BookingPatientAppointment>();
		BookingPatientAppointment a=null;
		try {
			String sql="select * from Patient_Registration";
			PreparedStatement ps= connection.prepareStatement(sql);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				a=new 	BookingPatientAppointment();
				a.setPatientID(rs.getInt(1));
				a.setPatientName(rs.getString(2));
				a.setPhone(rs.getString(4));
				a.setPatientaddress(rs.getString(6));
				list.add(a);
				 
			}
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		
		return list;
	}

//	
//	public boolean addDetails() {
//		boolean f= false;
//		try {
//			String sql="";
//			PreparedStatement ps=connection .prepareStatement(sql);
//			
//			ps.setString(1, bookap.getPatientID() );
//			ps.setString(2, associate.getAssociateName() );
//			ps.setString(3, associate.getAssociateTrack() );
//        	ps.setString(4, associate.getAssociateQualification() );
//			ps.setString(5, associate.getAssociateExperience() );
//
//			int i=ps.executeUpdate();
//			if(i==1) {
//				f=true;
//			}
//		}catch( Exception e) {
//			e.printStackTrace();
//		}
//		
//		return f;
//	}
	
	
//	public BookingPatientAppointment getAssociateById(int id) {
//		BookingPatientAppointment a=null;
//		try {
//			String sql="select * from associate where Associate_id=?";
//			PreparedStatement ps= connection.prepareStatement(sql);
//			ps.setInt(1,id);
//			ResultSet rs= ps.executeQuery();
//			
//			while(rs.next()) {
//				
//				a=new BookingPatientAppointment();
//				a.setAssociateId(rs.getString(1));
//				a.setAssociateName(rs.getString(2));
//				a.setAssociateTrack(rs.getString(3));
//				a.setAssociateQualification(rs.getString(4));
//				a.setAssociateExperience(rs.getString(5));
//                 
//			}
//		}catch(Exception e) {
//			e.printStackTrace();
//			
//		}
//		return a;
//		
//		
//	}



}




//
//
//import static java.lang.System.out;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Scanner;
//
//import org.apache.log4j.Logger;
//
//import com.revature.app.Application;
//import com.revature.constant.Constant;
//import com.revature.dao.AssociateDao;
//import com.revature.jdbc.util.ConnectionFactory;
//import com.revature.jdbc.util.DbUtil;
//import com.revature.jdbc.util.QueryConstants;
//import com.revature.model.Associate;
//import com.revature.model.AssociateTrack;
//import com.revature.model.Menu;
//
//public class AssociateDaoImp extends Associate implements AssociateDao{
//	
//	private static final Logger logger= Logger.getLogger(AssociateDaoImp.class);
//	private Connection conn;
//	
//	public AssociateDaoImp(Connection conn) {
//		super();
//		this.conn=conn;
//	}
//	@Override
//
//	@Override
//	public List<Associate> getAllAssociate() {
//		List<Associate> list=new ArrayList<Associate>();
//		 Associate a=null;
//		try {
//			String sql="select * from associate";
//			PreparedStatement ps= conn.prepareStatement(sql);
//			ResultSet rs= ps.executeQuery();
//			
//			while(rs.next()) {
//				
//				a=new Associate();
//				a.setAssociateId(rs.getString(1));
//				a.setAssociateName(rs.getString(2));
//				a.setAssociateTrack(rs.getString(3));
//				a.setAssociateQualification(rs.getString(4));
//				a.setAssociateExperience(rs.getString(5));
//                
//				list.add(a);
//				 
//			}
//		}catch(Exception e) {
//			e.printStackTrace();
//			
//		}
//		
//		return list;
//	}
//
//
//	@Override
//	public Associate getAssociateById(int id) {
//		Associate a=null;
//		try {
//			String sql="select * from associate where Associate_id=?";
//			PreparedStatement ps= conn.prepareStatement(sql);
//			ps.setInt(1,id);
//			ResultSet rs= ps.executeQuery();
//			
//			while(rs.next()) {
//				
//				a=new Associate();
//				a.setAssociateId(rs.getString(1));
//				a.setAssociateName(rs.getString(2));
//				a.setAssociateTrack(rs.getString(3));
//				a.setAssociateQualification(rs.getString(4));
//				a.setAssociateExperience(rs.getString(5));
//                 
//			}
//		}catch(Exception e) {
//			e.printStackTrace();
//			
//		}
//		return a;
//		
//		
//	}
//
//
//	@Override
//	public void deleteAssociateaDetails() {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public void updateAssociateDetails() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	}


//<%
//Connection connection = null;
//Statement statement = null;
//
//	
//try{
//	Class.forName("com.mysql.cj.jdbc.Driver");
//	String url="jdbc:mysql://localhost:3306/pams_own";
//	connection=DriverManager.getConnection(url, "root", "root");
//	statement = connection.createStatement();
//	ResultSet resultSet = statement.executeQuery("select * from Patient_Registration");
//	while(resultSet.next()){
//
//%>
//
//<tr>
//
//<td><% out.println(resultSet.getInt(1)); %></td>
//<td><% out.println(resultSet.getString(2)); %></td>
//<td><% out.println(resultSet.getString(4)); %></td>
//<td><% out.println(resultSet.getString(6)); %></td>
//
//<td>
//  <button
//  name="${resultSet.getInt(1) }"
//  value='${resultSet.getInt(1)}'
//    type="submit"
//    class="btn btn-primary"
//    data-toggle="modal"
//    data-target="#exampleModalCenter"
//  >
//    Book
//  </button>
//</td>
//
//</tr>
//<%
//}
//	}
//catch(Exception e){
//	e.printStackTrace();
// 
//}%>
