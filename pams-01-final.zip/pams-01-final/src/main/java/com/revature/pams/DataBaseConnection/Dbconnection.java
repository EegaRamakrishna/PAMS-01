package com.revature.pams.DataBaseConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Dbconnection
	{
		private static Connection connection = null;

		private Dbconnection() {
		}

		public static Connection getConnection() {
			if (connection == null) {
				String url="jdbc:mysql://localhost:3306/pams_own";
	        	String username="root";
	        	String Password="root";

				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					connection = DriverManager.getConnection(url,username,Password);
					System.out.println("Connected");
				} catch (ClassNotFoundException | SQLException e) {
					
					System.out.println("Class Not Found");
					e.printStackTrace();
					
				}
			}
			return connection;
		}
	}

