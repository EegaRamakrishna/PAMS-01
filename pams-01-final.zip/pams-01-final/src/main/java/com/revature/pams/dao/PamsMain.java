/**
 * 
 */
package com.revature.pams.dao;

import java.sql.SQLException;

/**
 * @author eegar
 *
 */
public interface PamsMain {

	public  void bookingAppointmen() throws SQLException;
	public void PatientRegister() throws SQLException, ClassNotFoundException;
	public  void LoginCredential() throws SQLException;
	
}
