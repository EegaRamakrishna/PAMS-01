package com.revature.pams.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.cj.protocol.Resultset;
import com.revature.pams.DataBaseConnection.Dbconnection;
import com.revature.pams.model.BookingPatientAppointment;

/**
 * Servlet implementation class BookingAppointmentServlet
 */
@WebServlet("/bookappointmentsvt")
public class BookingAppointmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDispatcher dispatcher=null;
	PreparedStatement pstbook;
//	int patientId;
	static String patientName;
	BookingPatientAppointment bookingPatientAppointment=new BookingPatientAppointment();
    public BookingAppointmentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    Dbconnection dbconnection = null;
	Connection connection = Dbconnection.getConnection();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println(request.getParameter("currentid1"+"geeting idddddddddddddddddd"));
		String a=request.getParameter("currentid");
		int i=Integer.parseInt(a); 
		request.setAttribute("currentid", i);
//		List<BookingPatientAppointment> patientList = new ArrayList<>();
//		String Patient_Registration_query="select * from Patient_Registration where Patient_id=?";
//	
		try {
			PreparedStatement PStm=connection.prepareStatement("select * from Patient_Registration where Patient_id=? ;");
			PStm.setInt(1,i);
			
			System.out.println(PStm);
			ResultSet resultset=PStm.executeQuery();
			if(resultset.next()) {
				bookingPatientAppointment.setPatientID(resultset.getInt(1));
				bookingPatientAppointment.setPatientName(resultset.getString(2));
				bookingPatientAppointment.setPhone(resultset.getString(4));
				
				LocalDate curDate = LocalDate.now();
				String pdate=resultset.getString(5);
				LocalDate dob = LocalDate.parse(pdate);  
				Period.between(dob, curDate).getYears();
				System.out.println(Period.between(dob, curDate).getYears());
				
//				bookingPatientAppointment.setDob(resultset.getDate(5));
				bookingPatientAppointment.setAge(Period.between(dob, curDate).getYears());
				bookingPatientAppointment.setPatientaddress(resultset.getString(6));
				bookingPatientAppointment.setGender(resultset.getString(8));
				bookingPatientAppointment.setPatientAilmentSymptoms(request.getParameter("symponts"));
				bookingPatientAppointment.setPatientAppointmentDate(request.getParameter("Date"));
				bookingPatientAppointment.setPatientAppointmentSlot(request.getParameter("Timeslot"));
				bookingPatientAppointment.setDoctorName(request.getParameter("doctorlist"));
//				System.out.println(bookingPatientAppointment.getDoctorName());
				String docName=bookingPatientAppointment.getDoctorName();
				PreparedStatement PStm1=connection.prepareStatement("select * from DOCTOR_RECORD where DOCTOR_NAME=?");
				PStm1.setString(1,docName);
				
				System.out.println(PStm1);
//				System.out.println(bookingPatientAppointment.getPatientName());
				ResultSet resultset1=PStm1.executeQuery();
				if(resultset1.next()) {
					bookingPatientAppointment.setDoctorFee(resultset1.getInt("CONSULTING_CHARGE"));
				}
//				System.out.println(bookingPatientAppointment.getDoctorFee());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		Patient_id int not null auto_increment primary KEY,
//		Patient_Name varchar(30),
//		Age int,
//		Contact_No varchar(20),
//		Address varchar(50),
//		Appointment_Date date,
//		Preferred_TimeSlot time,
//		Ailment_Symptoms varchar(200),
//		Doctor_Name varchar(30),
//		Doctor_fee int,
//		Status varchar(200)
		
		String appointmentBookingQuery = "insert into Book_Appointment(Patient_ID,Patient_Name,Age,Contact_No,"
				+ "Sex,Address,Appointment_Date,"
				+ "Preferred_TimeSlot,Ailment_Symptoms,Doctor_Name,Doctor_Fee,Status) values(?,?,?,?,?,?,?,?,?,?,?,?);";
		
		try {
			pstbook=connection.prepareStatement(appointmentBookingQuery);
			pstbook.setInt(1, bookingPatientAppointment.getPatientID());
			pstbook.setString(2,bookingPatientAppointment.getPatientName());
			pstbook.setInt(3,bookingPatientAppointment.getAge());
			pstbook.setString(4,bookingPatientAppointment.getPhone());
			pstbook.setString(5,bookingPatientAppointment.getGender());
			pstbook.setString(6,bookingPatientAppointment.getPatientaddress());
			pstbook.setString(7, bookingPatientAppointment.getPatientAppointmentDate());
			pstbook.setString(8,bookingPatientAppointment.getPatientAppointmentSlot());
			pstbook.setString(9,bookingPatientAppointment.getPatientAilmentSymptoms());
			pstbook.setString(10,bookingPatientAppointment.getDoctorName());
			pstbook.setInt(11,bookingPatientAppointment.getDoctorFee());
			pstbook.setString(12, bookingPatientAppointment.getStatus());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
//		System.out.println(bookingPatientAppointment.getPatientID());
//		System.out.println(bookingPatientAppointment.getPatientName());
//		System.out.println(bookingPatientAppointment.getAge());
//		
//		System.out.println(bookingPatientAppointment.getPhone());
//		System.out.println(bookingPatientAppointment.getPatientaddress());
//		System.out.println(bookingPatientAppointment.getPatientAppointmentDate());
//		System.out.println(bookingPatientAppointment.getPatientAppointmentSlot());
//		System.out.println(bookingPatientAppointment.getPatientAilmentSymptoms());
//		System.out.println(bookingPatientAppointment.getDoctorName());
//		System.out.println(bookingPatientAppointment.getDoctorFee());
//		System.out.println(bookingPatientAppointment.getGender());
		
		
		String docAvlCheck = "select Appointment_Date,Preferred_TimeSlot,Doctor_Name"
				+ " from book_appointment where Appointment_Date= '"
				+ bookingPatientAppointment.getPatientAppointmentDate() + "'"
				+ " && Preferred_TimeSlot=" + '"' + bookingPatientAppointment.getPatientAppointmentSlot()
				+ '"' + " and Doctor_Name='" + bookingPatientAppointment.getDoctorName() + "'";

		System.out.println(docAvlCheck);

		Statement statement;
		int count=0;
		try {
			
			statement = connection.createStatement();
			ResultSet checkAvil = statement.executeQuery(docAvlCheck);
			while (checkAvil.next()) {
				
				System.out.println(checkAvil.getString(1) + "  " + checkAvil.getString(2));
				count++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (count == 0) {
			bookingPatientAppointment.setStatus("Conformed");
			try {
				pstbook=connection.prepareStatement(appointmentBookingQuery);
				pstbook.setInt(1, bookingPatientAppointment.getPatientID());
				pstbook.setString(2,bookingPatientAppointment.getPatientName());
				pstbook.setInt(3,bookingPatientAppointment.getAge());
				pstbook.setString(4,bookingPatientAppointment.getPhone());
				pstbook.setString(5,bookingPatientAppointment.getGender());
				pstbook.setString(6,bookingPatientAppointment.getPatientaddress());
				pstbook.setString(7, bookingPatientAppointment.getPatientAppointmentDate());
				pstbook.setString(8,bookingPatientAppointment.getPatientAppointmentSlot());
				pstbook.setString(9,bookingPatientAppointment.getPatientAilmentSymptoms());
				pstbook.setString(10,bookingPatientAppointment.getDoctorName());
				pstbook.setInt(11,bookingPatientAppointment.getDoctorFee());
				pstbook.setString(12, bookingPatientAppointment.getStatus());

				int bookingappoint=pstbook.executeUpdate();
				if(bookingappoint==1) {
					request.setAttribute("status", "success");
					System.out.println("Booked");
					dispatcher=request.getRequestDispatcher("bookappointment.jsp");
					dispatcher.forward(request, response);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if(count==1) {
			
			request.setAttribute("status", "failed");
			dispatcher=request.getRequestDispatcher("bookappointment.jsp");
			dispatcher.forward(request, response);
			System.out.println("Slot is not availble");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
