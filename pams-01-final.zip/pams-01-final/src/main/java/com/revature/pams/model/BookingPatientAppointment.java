/**
 * 
 */
package com.revature.pams.model;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.revature.pams.DataBaseConnection.Dbconnection;



/**
 * @author eegar
 *
 */
public class BookingPatientAppointment{
	
	Connection connection = Dbconnection.getConnection();
	private String phone;
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	private int patientID;
	private String patientName;
	private Date dob;
	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	private int age;
	private String patientAppointmentSlot;
	private  String patientaddress;
	private  String patientAppointmentDate;
	/**
	 * 
	 */
	public BookingPatientAppointment() {
		super();
	}

	public String getPatientAppointmentDate() {
		return patientAppointmentDate;
	}

	public void setPatientAppointmentDate(String patientAppointmentDate) {
		this.patientAppointmentDate = patientAppointmentDate;
	}

	private  String patientAilmentSymptoms;
	private String doctorName;
	private int doctorFee;
	private String status;
	private String Gender;
	
	
	

	

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	/**
	 * @param patientID
	 * @param patientName
	 * @param age
	 * @param patientaddress
	 */
	public BookingPatientAppointment(int patientID, String patientName, short age, String patientaddress) {
		super();
		this.patientID = patientID;
		this.patientName = patientName;
		this.age = age;
		this.patientaddress = patientaddress;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPatientAppointmentSlot() {
		return patientAppointmentSlot;
	}

	public void setPatientAppointmentSlot(String patientAppointmentSlot) {
		this.patientAppointmentSlot = patientAppointmentSlot;
	}


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getDoctorFee() {
		return doctorFee;
	}

	public void setDoctorFee(int doctorFee) {
		this.doctorFee = doctorFee;
	}

	public int getPatientID() {
		return patientID;
	}
	
	public void setPatientID(int patientID) {
		this.patientID = patientID;
	}


	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getPatientaddress() {
		return patientaddress;
	}
	@Override
	public String toString() {
		return "BookingPatientAppointment [phone=" + phone + ", patientID=" + patientID + ", patientName=" + patientName
				+ ", age=" + age + ", patientAppointmentSlot=" + patientAppointmentSlot + ", patientaddress="
				+ patientaddress + ", patientAppointmentDate=" + patientAppointmentDate + ", patientAilmentSymptoms="
				+ patientAilmentSymptoms + ", doctorName=" + doctorName + ", doctorFee=" + doctorFee + ", status="
				+ status + "]";
	}

	public void setPatientaddress(String patientaddress) {
		this.patientaddress = patientaddress;
	}
	
	public String getPatientAilmentSymptoms() {
		return patientAilmentSymptoms;
	}
	

	public void setPatientAilmentSymptoms(String patientAilmentSymptoms) {
		this.patientAilmentSymptoms = patientAilmentSymptoms;
	}
	

	

	
	
	
}